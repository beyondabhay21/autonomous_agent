# 🚗 autonomous_agent (ROS 2 Python)

This repository contains a **ROS 2 package** for an autonomous driving agent scaffold.  
It demonstrates a typical pipeline for a self-driving simulation using **CARLA + ROS 2 + PyTorch**.

## 📌 Features
- `camera_bridge`: Republish CARLA camera images into ROS 2
- `inference_node`: Run PyTorch model on camera input → produce control commands
- `control_node`: Consume Twist commands and map them to simulator/robot control

## 🛠️ Tech Stack
- **ROS 2** (rclpy)
- **PyTorch**
- **OpenCV**
- **CARLA simulator**

## 📂 Project Structure
```
autonomous_agent/
├── package.xml
├── setup.py / setup.cfg / requirements.txt
├── autonomous_agent/
│   ├── nodes/ (ROS 2 Python nodes)
│   ├── models/ (PyTorch model + loader)
│   └── utils/ (helper scripts)
├── launch/ (launch files)
├── resource/
├── LICENSE
└── README.md
```

## 🚀 Getting Started

### 1. Clone repository
```bash
git clone https://github.com/<your-username>/autonomous_agent.git
cd autonomous_agent
```

### 2. Install dependencies
```bash
pip3 install -r requirements.txt
```

### 3. Build ROS 2 workspace
```bash
mkdir -p ~/ros2_ws/src
cp -r autonomous_agent ~/ros2_ws/src/
cd ~/ros2_ws
colcon build --symlink-install
source install/setup.bash
```

### 4. Launch the system
```bash
ros2 launch autonomous_agent agent_launch.py
```

## 📜 License
This project is licensed under the MIT License. See [LICENSE](LICENSE) for details.

---
💡 Pro tip: Fork this repo, add your trained model, and customize `control_node` for CARLA or a real robot!
