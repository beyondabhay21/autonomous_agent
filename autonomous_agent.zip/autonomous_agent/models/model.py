import torch
import torch.nn as nn
import torch.nn.functional as F

class SimpleConvNet(nn.Module):
    def __init__(self, num_outputs=2):
        super().__init__()
        self.conv1 = nn.Conv2d(3, 16, 5, stride=2)
        self.conv2 = nn.Conv2d(16, 32, 5, stride=2)
        self.conv3 = nn.Conv2d(32, 64, 3, stride=2)
        self.fc1 = nn.Linear(64*25*25, 128)
        self.fc2 = nn.Linear(128, num_outputs)

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = F.relu(self.conv2(x))
        x = F.relu(self.conv3(x))
        x = x.view(x.size(0), -1)
        x = F.relu(self.fc1(x))
        return self.fc2(x)

def load_model(path=None, device='cpu'):
    model = SimpleConvNet(num_outputs=2)
    if path:
        state = torch.load(path, map_location=device)
        model.load_state_dict(state)
    model.to(device)
    model.eval()
    return model
