#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

class CameraBridge(Node):
    def __init__(self):
        super().__init__('camera_bridge')
        self.declare_parameter('input_topic', '/carla/ego_vehicle/camera/rgb')
        self.declare_parameter('output_topic', '/camera/image_raw')
        in_t = self.get_parameter('input_topic').get_parameter_value().string_value
        out_t = self.get_parameter('output_topic').get_parameter_value().string_value

        self.bridge = CvBridge()
        self.sub = self.create_subscription(Image, in_t, self.cb_image, 10)
        self.pub = self.create_publisher(Image, out_t, 10)
        self.get_logger().info(f'CameraBridge: subscribing {in_t} -> publishing {out_t}')

    def cb_image(self, msg):
        self.pub.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = CameraBridge()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()
