#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class ControlNode(Node):
    def __init__(self):
        super().__init__('control_node')
        self.declare_parameter('input_topic', '/cmd_vel')
        self.input_topic = self.get_parameter('input_topic').value
        self.sub = self.create_subscription(Twist, self.input_topic, self.cb_cmd, 10)
        self.get_logger().info(f'ControlNode: subscribed to {self.input_topic}')

    def cb_cmd(self, msg: Twist):
        self.get_logger().info(f'Received control -> linear.x: {msg.linear.x:.3f}, angular.z: {msg.angular.z:.3f}')

def main(args=None):
    rclpy.init(args=args)
    node = ControlNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()
