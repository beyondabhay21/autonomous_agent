#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge
import numpy as np
import torch
from autonomous_agent.models.model import load_model
from autonomous_agent.utils.preprocess import preprocess_image

class InferenceNode(Node):
    def __init__(self):
        super().__init__('inference_node')
        self.declare_parameter('image_topic', '/camera/image_raw')
        self.declare_parameter('control_topic', '/cmd_vel')
        self.declare_parameter('model_path', '')
        self.declare_parameter('device', 'cpu')
        self.img_topic = self.get_parameter('image_topic').value
        self.ctrl_topic = self.get_parameter('control_topic').value
        self.model_path = self.get_parameter('model_path').value
        self.device = self.get_parameter('device').value

        self.bridge = CvBridge()
        self.sub = self.create_subscription(Image, self.img_topic, self.cb_image, 1)
        self.pub = self.create_publisher(Twist, self.ctrl_topic, 10)

        self.get_logger().info(f'InferenceNode: subscribing {self.img_topic}, publishing {self.ctrl_topic}')
        self.model = load_model(self.model_path if self.model_path else None, device=self.device)
        self.get_logger().info('Model loaded')

    def cb_image(self, msg):
        try:
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as e:
            self.get_logger().error(f'cv_bridge error: {e}')
            return
        x = preprocess_image(cv_image)
        x = np.expand_dims(x, 0)
        x_tensor = torch.from_numpy(x).float().to(self.device)
        with torch.no_grad():
            out = self.model(x_tensor)
        steering, throttle = out[0,0].item(), out[0,1].item()
        twist = Twist()
        twist.linear.x = float(throttle)
        twist.angular.z = float(steering)
        self.pub.publish(twist)

def main(args=None):
    rclpy.init(args=args)
    node = InferenceNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()
