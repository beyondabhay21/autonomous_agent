import cv2
import numpy as np

def preprocess_image(cv_image, size=(224, 224)):
    img = cv2.cvtColor(cv_image, cv2.COLOR_BGR2RGB)
    img = cv2.resize(img, size)
    img = img.astype('float32') / 255.0
    img = np.transpose(img, (2, 0, 1))
    return img
