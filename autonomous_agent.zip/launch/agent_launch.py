from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    ld = LaunchDescription()

    camera_bridge = Node(
        package='autonomous_agent',
        executable='camera_bridge',
        name='camera_bridge',
        parameters=[{
            'input_topic': '/carla/ego_vehicle/camera/rgb',
            'output_topic': '/camera/image_raw',
        }],
    )

    inference = Node(
        package='autonomous_agent',
        executable='inference_node',
        name='inference_node',
        parameters=[{
            'image_topic': '/camera/image_raw',
            'control_topic': '/cmd_vel',
            'model_path': '',
            'device': 'cpu',
        }],
    )

    control = Node(
        package='autonomous_agent',
        executable='control_node',
        name='control_node',
        parameters=[{
            'input_topic': '/cmd_vel',
        }],
    )

    ld.add_action(camera_bridge)
    ld.add_action(inference)
    ld.add_action(control)
    return ld
